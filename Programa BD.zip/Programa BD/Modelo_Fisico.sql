-- Gera��o de Modelo f�sico
-- Sql ANSI 2003 - brModelo.



CREATE TABLE Compras (
Data_Compra date,
Codigo_Compra Integer PRIMARY KEY,
Valor_Total_Compra double precision,
Codigo_F Integer,
Codigo_Caixa integer
)

CREATE TABLE Fornecedores (
Cidade_F varchar,
Complemento_F varchar,
Bairro_F varchar,
Logradouro_F varchar,
Nome_Fantasia varchar,
EMAIL_F varchar,
Numero_F Integer,
Telefone_F varchar,
CEP_F varchar,
Razao_Social varchar,
UF_F varchar,
CNPJ bigint,
Codigo_F integer PRIMARY KEY
)

CREATE TABLE Tipos_Produtos  (
Codigo_TP integer PRIMARY KEY,
Descricao_TP varchar
)

CREATE TABLE Produtos (
Codigo_P Integer PRIMARY KEY,
Descricao_P String,
Estoque_P Integer,
Codigo_Barras_P Integer,
Estoque_Minimo_P Integer,
Valor_P double precision,
Codigo_TP Integer
)

CREATE TABLE caixa (
Codigo_Caixa Integer PRIMARY KEY,
Entradas_Caixa Integer,
Saidas_Caixa Texto(1),
Data_Venda String
)

CREATE TABLE Clientes (
CEP_Client String,
Bairro_Client String,
UF_Client String,
Complemento_Client String,
Cidade_Client String,
Data_de_Nascimento_Client date,
CPF_Client String,
Codigo_Client Integer PRIMARY KEY,
Numero_Client Integer,
Logradouro_Client String,
Nome_Cadas_Client String,
Telefone_Client String
)

CREATE TABLE Vendas (
Tipos_Pagamento Integer,
Codigo_Client Integer,
Valor_Total_Venda Float,
Data_Venda date,
Codigo_Caixa Texto(1),
Codigo_Venda Integer PRIMARY KEY
)

