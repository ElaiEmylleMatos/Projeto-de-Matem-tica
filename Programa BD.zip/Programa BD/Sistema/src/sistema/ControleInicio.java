/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistema;

import dados.Conexao;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;
import telas.tela_fluxo;
import telas.tela_inicial;
import telas.tela_produtos;
import telas.tela_todosClientes;
import telas.tela_todosFornecedores;

/**
 *
 * @author Emylle Matos
 */
public class ControleInicio {
    
    private tela_inicial ti;
    private tela_produtos tp;
    private tela_todosClientes tc;
    private tela_todosFornecedores tf;
    private tela_fluxo tfl;
    
    public ControleInicio(){
    
        ti = new tela_inicial();
        ti.setVisible(true);       
        ti.getestoque().addActionListener(new TelaProdutos());
        ti.getfornecedor().addActionListener(new TelaForn());
        ti.getcliente().addActionListener(new TelaCliente());
        ti.getfluxo().addActionListener(new TelaFluxo());
        
    }

    private class TelaCliente implements ActionListener {
        public void actionPerformed(ActionEvent e){
            tc = new tela_todosClientes();
            tc.setVisible(true);
            
            try {
            DefaultTableModel modelo = (DefaultTableModel)tp.getjTable1().getModel();
                Statement st = Conexao.getConexao().createStatement();
                ResultSet r = st.executeQuery("Select * from cliente order by codigoClient");
                ResultSet q = st.executeQuery("select count(codigo_cliente) from cliente");
                int y = q.getInt("codigo_cliente");
                q.next();
                r.next();
                            
           for(int i = 0;i<y;i++){
            String ro[] = {r.getString("Nome_cadasClient"),"",r.getString("Telefone_Cli"),r.getString("logradouro")+","+r.getInt("numero")+","+r.getString("bairro")+","+r.getString("cidade")+","+r.getString("uf")};
            modelo.addRow(ro);
            r.next();
           }
            tp.getjTable1().setModel(modelo);
        } catch(SQLException ex){
            System.out.println (ex.getMessage());
        }
            
        }
    }
    
    private class TelaForn implements ActionListener {
        public void actionPerformed(ActionEvent e){
            tf = new tela_todosFornecedores();
            tf.setVisible(true);
            
            try {
            DefaultTableModel modelo = (DefaultTableModel)tp.getjTable1().getModel();
                Statement st = Conexao.getConexao().createStatement();
                ResultSet r = st.executeQuery("Select * from fornecedores order by CNPJ");
                r.next();
                            
           for(int i = 0;i<50;i++){
            String ro[] = {r.getString("Razao_Social"),"",r.getString("Telefone_F"),r.getString("EMAIL_F"),r.getString("logradouro")+","+r.getInt("numero")+","+r.getString("bairro")+","+r.getString("cidade")+","+r.getString("uf")};
            modelo.addRow(ro);
            r.next();
           }
            tp.getjTable1().setModel(modelo);
        } catch(SQLException ex){
            System.out.println (ex.getMessage());
        }
            
        }
    }

    private class TelaProdutos implements ActionListener {
        public void actionPerformed(ActionEvent e){
        //    tp = new tela_produtos();
         //   tp.setVisible(true);
            ControleProdutos cp = new ControleProdutos();
            //cp.getDadosTabela();
            
            //cp.getExcluir();
        }
    }
    
    private class TelaFluxo implements ActionListener {
        public void actionPerformed(ActionEvent e){
            tfl = new tela_fluxo();
            tfl.setVisible(true);
        }
    }
    
}
