/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistema;

import dados.Conexao;
import dados.Produtos;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import telas.tela_produtos;

/**
 *
 * @author Emylle Matos
 */
public class ControleProdutos {
    //  private ControleProdutos cp;

    private Produtos p;
    private tela_produtos tp;
    private ResultSet r;
    private Statement st;

    public ControleProdutos() {
        p = new Produtos();
        tp = new tela_produtos();
        exibeDadosTabela();
        tp.setVisible(true);

        tp.getVoltar().addActionListener(new Voltar());
        tp.getexcluir().addActionListener(new Excluir());
    }

    private class Voltar implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            tp.dispose();
        }
    }

    private class Excluir implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            
            try {
            
            if (tp.getjTable1().getSelectedRow() >= 0) {
                int resp = JOptionPane.showConfirmDialog(tp, "Deseja excluir?","Excluir",JOptionPane.YES_OPTION);
                
               if(resp == JOptionPane.YES_OPTION){
                DefaultTableModel modelo = (DefaultTableModel) tp.getjTable1().getModel();
                modelo.removeRow(tp.getjTable1().getSelectedRow());
                tp.getjTable1().setModel(modelo);
                
                p.ExcluirProdutos();
               }
            } else {
                JOptionPane.showMessageDialog(tp, "Selecione um produto");
            }
            }
            catch(Exception ex) {
            System.out.println(ex.getMessage());
        }
        }
    }

    public void exibeDadosTabela() {
        try {
            DefaultTableModel modelo = (DefaultTableModel) tp.getjTable1().getModel();
            Statement st = Conexao.getConexao().createStatement();
            ResultSet r = st.executeQuery("Select * from produto order by codigo_p");

            r.next();

            for (int i = 0; i < 50; i++) {
                String ro[] = {r.getInt("codigo_p") + "", r.getString("nome"), "", r.getInt("quant") + ""};
                modelo.addRow(ro);
                r.next();
            }
            tp.getjTable1().setModel(modelo);
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

    }
}
