/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistema;

import dados.Clientes;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.Statement;
import telas.tela_cliente;
import telas.tela_todosClientes;

/**
 *
 * @author Emylle Matos
 */
public class ControleCliente {
    private tela_cliente tc;
    private Clientes c;
    private ControleTodosClientes ctc;
    private static tela_todosClientes ttc;
    private Statement st;
    private ResultSet rs;
    
    public ControleCliente(){
        tc = new tela_cliente();
        c = new Clientes();
        ctc = new ControleTodosClientes();
        ttc = new tela_todosClientes();
        
        ttc.getVoltar().addActionListener(new Sair());
        ttc.getnovo().addActionListener(new Novo());
    }
        
    /* public class TodosC implements ActionListener{
      public void actionPerformed(ActionEvent e){
          tc.setVisible(false);
          ttc.setVisible(true);
      }
    }*/
   
    
     public class Sair implements ActionListener{
      public void actionPerformed(ActionEvent e){
          System.exit(0);
      }
    }
     
    public class Novo implements ActionListener{
      public void actionPerformed(ActionEvent e){
          tc.setVisible(true);
          c = new Clientes();
      }
    }
    
}
