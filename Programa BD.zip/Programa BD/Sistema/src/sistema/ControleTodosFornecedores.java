/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistema;

import dados.Fornecedores;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import telas.tela_fornecedores;
import telas.tela_todosFornecedores;

/**
 *
 * @author Emylle Matos
 */
public class ControleTodosFornecedores {
    private tela_todosFornecedores ttf;
    private tela_fornecedores tf;
    private Fornecedores f;
    
    public ControleTodosFornecedores(){
     ttf = new tela_todosFornecedores();
     tf = new tela_fornecedores();
     ttf.getinserir().addActionListener(new Novo());
    }
    
    private class Novo implements ActionListener {
        public void actionPerformed(ActionEvent e){
            tf.setVisible(true);
        }
    }
  
}
