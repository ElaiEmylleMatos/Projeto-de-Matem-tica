/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistema;

import telas.tela_todosClientes;

/**
 *
 * @author Emylle Matos
 */
public class ControleTodosClientes {
    private tela_todosClientes tcc;
    
    public ControleTodosClientes() {
        tcc = new tela_todosClientes();
        tcc.setVisible(true);
    }
}
