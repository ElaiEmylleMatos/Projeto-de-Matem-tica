/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistema;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import telas.tela_fornecedores;

/**
 *
 * @author Emylle Matos
 */
public class ControleFornecedores {
    private tela_fornecedores tf;
    private boolean valCNPJ;
    private boolean valTel;
    
    public ControleFornecedores() {
        tf = new tela_fornecedores();
        
        tf.getjFormattedTextField1().addFocusListener(new ValidaCNPJ());
        tf.getjFormattedTextField2().addFocusListener(new ValidaTel());
        tf.getsalvar().addActionListener(new Salvar());
    }
    
    public class ValidaCNPJ implements FocusListener {
        public void focusLost(FocusEvent f){
            
            String CNPJ = tf.getjFormattedTextField1().getText();
            
            if (CNPJ.equals("00000000000000") || CNPJ.equals("11111111111111") ||
                CNPJ.equals("22222222222222") || CNPJ.equals("33333333333333") ||
                CNPJ.equals("44444444444444") || CNPJ.equals("55555555555555") ||
                CNPJ.equals("66666666666666") || CNPJ.equals("77777777777777") ||
                CNPJ.equals("88888888888888") || CNPJ.equals("99999999999999") ||
                (CNPJ.length() != 14))
            {
                JOptionPane.showMessageDialog(tf, "CNPJ inválido");
                valCNPJ = false;
            } else {
                
                char dig13, dig14;
                int sm, i, r, num, peso;
            
                sm = 0;
                peso = 2;
                for (i=11; i>=0; i--) {
                    num = (int)(CNPJ.charAt(i) - 48);
                    sm = sm + (num * peso);
                    peso = peso + 1;
                    if (peso == 10)
                        peso = 2;
                }
                r = sm % 11;
                if ((r == 0) || (r == 1))
                    dig13 = '0';
                else dig13 = (char)((11-r) + 48);
                sm = 0;
                peso = 2;
                for (i=12; i>=0; i--) {
                    num = (int)(CNPJ.charAt(i)- 48);
                    sm = sm + (num * peso);
                    peso = peso + 1;
                    if (peso == 10){
                        peso = 2;
                    }
                }
                r = sm % 11;
                if ((r == 0) || (r == 1))
                    dig14 = '0';
                else dig14 = (char)((11-r) + 48);
                // Verifica se os dígitos calculados conferem com os dígitos informados.
                if ((dig13 != CNPJ.charAt(12)) && (dig14 != CNPJ.charAt(13))){
                    JOptionPane.showMessageDialog(tf, "CNPJ inválido");
                    valCNPJ = false;}
                else valCNPJ = true;
            }
        }

        @Override
        public void focusGained(FocusEvent e) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }   
        }

    public class ValidaTel implements FocusListener {
        public void focusLost(FocusEvent f){
            String tel = tf.getjFormattedTextField2().getText();
            
            if((tel == null) || (tel.length()!=13) || (!tel.matches(".((10)|([1-9][1-9]).)\\s9?[6-9][0-9]{3}-[0-9]{4}"))){
                JOptionPane.showMessageDialog(tf, "Telefone inválido");
                valTel = false;}
            else {
                valTel = true;
            }
        }
        @Override
        public void focusGained(FocusEvent e) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }
    
    public class Salvar implements ActionListener{
      public void actionPerformed(ActionEvent e){
          if(valCNPJ&&valTel){
          } else {
              
          }
      }
    }
}
