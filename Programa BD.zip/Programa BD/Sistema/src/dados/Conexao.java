/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dados;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author ALUNO
 */
public class Conexao {
    private static String StringDrive = "org.firebirdsql.jdbc.FBDriver";
    private static String caminhoDB = "jdbc:firebirdsql:localhost:C:\\Users\\Emylle Matos\\Desktop\\Programa BD\\sistema.fdb";
    private static String usuario = "sysdba";
    private static String senha =  "masterkey";
    
    public static Connection getConexao(){
        
        try {
            Class.forName(StringDrive);
            return DriverManager.getConnection(caminhoDB,usuario,senha);
        }
        catch(Exception e){
            System.out.println("oi");
        }
        return null;
    }
}
