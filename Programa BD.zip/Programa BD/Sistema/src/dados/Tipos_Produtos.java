/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dados;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Emylle Matos
 */
public class Tipos_Produtos {

    /**
     * @return the DescricaoTP
     */
    public String getDescricaoTP() {
        return DescricaoTP;
    }

    /**
     * @param DescricaoTP the DescricaoTP to set
     */
    public void setDescricaoTP(String DescricaoTP) {
        this.DescricaoTP = DescricaoTP;
    }

    /**
     * @return the CodigoTP
     */
    public int getCodigoTP() {
        return CodigoTP;
    }

    /**
     * @param CodigoTP the CodigoTP to set
     */
    public void setCodigoTP(int CodigoTP) {
        this.CodigoTP = CodigoTP;
    }
    private static String DescricaoTP;
    private static int CodigoTP;
    
    public void InserirTipos_Produtos(){
         PreparedStatement pst = null;         
        try { 
            pst = dados.Conexao.getConexao().prepareStatement("INSERT INTO Tipos_Produtos (CodigoTP, DescricaoTP) VALUES (?,?)");
            pst.setInt(1, CodigoTP);
            pst.setString(2,DescricaoTP);         
            pst.executeUpdate();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    
    public void EditarTipos_Produtos(){
         PreparedStatement pst = null;         
        try { 
            pst = dados.Conexao.getConexao().prepareStatement("UPDATE Tipos_Produtos SET CodigoTP = ?, DescricaoTP = ? WHERE CodigoTP = ?");
            pst.setInt(1, CodigoTP);
            pst.setString(2,DescricaoTP);
            pst.setInt(3, CodigoTP);
            pst.executeUpdate();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void ExcluirTipos_Produtos(){
         PreparedStatement pst = null;         
        try { 
            pst = dados.Conexao.getConexao().prepareStatement("DELETE FROM Tipos_Produtos WHERE CodigoTP = ?");
            pst.setInt(1, CodigoTP);
            pst.executeUpdate();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    public ResultSet SelecionarTipos_Produtos (String SQL){
        ResultSet rs = null;
        try {
           rs = Conexao.getConexao().createStatement().executeQuery(SQL);
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        return rs;
    }
}
