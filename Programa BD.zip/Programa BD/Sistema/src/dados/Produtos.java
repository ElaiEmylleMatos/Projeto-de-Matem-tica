/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dados;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Emylle Matos
 */
public class Produtos {
    
    /**
     * @return the Estoque
     */
    public int getEstoque() {
        return Estoque;
    }

    /**
     * @param Estoque the Estoque to set
     */
    public void setEstoque(int Estoque) {
        this.Estoque = Estoque;
    }

    /**
     * @return the Codigo_Barras
     */
    public int getCodigo_Barras() {
        return Codigo_Barras;
    }

    /**
     * @param Codigo_Barras the Codigo_Barras to set
     */
    public void setCodigo_Barras(int Codigo_Barras) {
        this.Codigo_Barras = Codigo_Barras;
    }

    /**
     * @return the Estoque_Minimo
     */
    public int getEstoque_Minimo() {
        return Estoque_Minimo;
    }

    /**
     * @param Estoque_Minimo the Estoque_Minimo to set
     */
    public void setEstoque_Minimo(int Estoque_Minimo) {
        this.Estoque_Minimo = Estoque_Minimo;
    }

    /**
     * @return the CodigoP
     */
    public int getCodigoP() {
        return Codigo_P;
    }

    /**
     * @param CodigoP the CodigoP to set
     */
    public void setCodigo_P(int CodigoP) {
        this.Codigo_P = CodigoP;
    }

    /**
     * @return the CodigoTP
     */
    public int getCodigoTP() {
        return CodigoTP;
    }

    /**
     * @param CodigoTP the CodigoTP to set
     */
    public void setCodigoTP(int CodigoTP) {
        this.CodigoTP = CodigoTP;
    }

    /**
     * @return the Descricao
     */
    public String getDescricao() {
        return Descricao;
    }

    /**
     * @param Descricao the Descricao to set
     */
    public void setDescricao(String Descricao) {
        this.Descricao = Descricao;
    }

    /**
     * @return the Valor
     */
    public float getValor() {
        return Valor;
    }

    /**
     * @param Valor the Valor to set
     */
    public void setValor(float Valor) {
        this.Valor = Valor;
    }
    private static int Estoque;
    private static int Codigo_Barras;
    private static int Estoque_Minimo;
    private static int Codigo_P;
    private static int CodigoTP;
    private static String Descricao;
    private static float Valor;
    private int gerarCodigo = 3539;
    
  /* public void InserirProdutos(){
         PreparedStatement pst = null;   
         gerarCodigo++;
        try { 
            pst = dados.Conexao.getConexao().prepareStatement("INSERT INTO Produtos (CodigoP, Estoque, Codigo_Barras, Estoque_Minimo, CodigoTP, Descricao, Valor) VALUES (?,?,?,?,?,?,?)");
            pst.setInt(1, CodigoP);
            pst.setInt(2, Estoque);
            pst.setInt(3, Codigo_Barras);
            pst.setInt(4, Estoque_Minimo);
            pst.setInt(5, Estoque_Minimo);
            pst.setString(6, Descricao);
            pst.setFloat(7, Valor);           
            pst.executeUpdate();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    
    public void EditarProdutos(){
         PreparedStatement pst = null;         
        try { 
            pst = dados.Conexao.getConexao().prepareStatement("UPDATE Produtos SET CodigoP = ?, Estoque = ?, Codigo_Barras = ?, Estoque_Minimo = ?, CodigoTP = ?, Descricao = ?, Valor = ? WHERE CodigoP = ?");
            pst.setInt(1, CodigoP);
            pst.setInt(2, Estoque);
            pst.setInt(3, Codigo_Barras);
            pst.setInt(4, Estoque_Minimo);
            pst.setInt(5, Estoque_Minimo);
            pst.setString(6, Descricao);
            pst.setFloat(7, Valor);
            pst.setInt(8, CodigoP);
            pst.executeUpdate();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }*/
    public void ExcluirProdutos(){
         PreparedStatement pst = null;         
        try { 
            pst = dados.Conexao.getConexao().prepareStatement("DELETE FROM Produto WHERE Codigo_P = ?");
            pst.setInt(1, Codigo_P);
            pst.executeUpdate();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    public ResultSet SelecionarProdutos (String SQL){
        ResultSet rs = null;
        try {
           rs = Conexao.getConexao().createStatement().executeQuery(SQL);
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        return rs;
    }
    
}
