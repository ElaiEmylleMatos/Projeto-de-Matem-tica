/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dados;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Emylle Matos
 */
public class Vendas {
    
    /**
     * @return the CodigoClient
     */  
    public int getCodigoClient() {
        return CodigoClient;
    }

    /**
     * @param CodigoClient the CodigoClient to set
     */
    public void setCodigoClient(int CodigoClient) {
        this.CodigoClient = CodigoClient;
    }

    /**
     * @return the CodigoV
     */
    public int getCodigoV() {
        return CodigoV;
    }

    /**
     * @param CodigoV the CodigoV to set
     */
    public void setCodigoV(int CodigoV) {
        this.CodigoV = CodigoV;
    }

    /**
     * @return the CodigoTiposPaga
     */
    public int getCodigoTiposPaga() {
        return CodigoTiposPaga;
    }

    /**
     * @param CodigoTiposPaga the CodigoTiposPaga to set
     */
    public void setCodigoTiposPaga(int CodigoTiposPaga) {
        this.CodigoTiposPaga = CodigoTiposPaga;
    }

    /**
     * @return the Valor_total_da_Comp
     */
    public float getValor_total_da_Comp() {
        return Valor_total_da_Comp;
    }

    /**
     * @param Valor_total_da_Comp the Valor_total_da_Comp to set
     */
    public void setValor_total_da_Comp(float Valor_total_da_Comp) {
        this.Valor_total_da_Comp = Valor_total_da_Comp;
    }

    /**
     * @return the Data_vendas
     */
    public Date getData_vendas() {
        return Data_vendas;
    }

    /**
     * @param Data_vendas the Data_vendas to set
     */
    public void setData_vendas(Date Data_vendas) {
        this.Data_vendas = Data_vendas;
    }
    private static int CodigoClient;
    private static int CodigoV;  
    private static int CodigoTiposPaga;
    private static float Valor_total_da_Comp;
    private static Date Data_vendas;
    
    public void InserirVendas(){
         PreparedStatement pst = null;         
        try { 
            pst = dados.Conexao.getConexao().prepareStatement("INSERT INTO Vendas (CodigoV, CodigoClient, CodigoTiposPaga, Valor_total_da_Comp, Data_vendas) VALUES (?,?,?,?,?)");
            pst.setInt(1, CodigoV);
            pst.setInt(2, CodigoClient);
            pst.setInt(3, CodigoTiposPaga);
            pst.setFloat(4,Valor_total_da_Comp);
            pst.setDate(5, Data_vendas);           
            pst.executeUpdate();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    
    public void EditarVendas(){
         PreparedStatement pst = null;         
        try { 
            pst = dados.Conexao.getConexao().prepareStatement("UPDATE Vendas SET CodigoV = ?, CodigoClient = ?, CodigoTiposPaga = ?, Valor_total_da_Comp = ?, Data_vendas = ? WHERE CodigoV = ?");
            pst.setInt(1, CodigoV);
            pst.setInt(2, CodigoClient);
            pst.setInt(3, CodigoTiposPaga);
            pst.setFloat(4,Valor_total_da_Comp);
            pst.setDate(5, Data_vendas);
            pst.setInt(6, CodigoV);
            pst.executeUpdate();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void ExcluirVendas(){
         PreparedStatement pst = null;         
        try { 
            pst = dados.Conexao.getConexao().prepareStatement("DELETE FROM Vendas WHERE CodigoV = ?");
            pst.setInt(1, CodigoV);
            pst.executeUpdate();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    public ResultSet SelecionarVendas (String SQL){
        ResultSet rs = null;
        try {
           rs = Conexao.getConexao().createStatement().executeQuery(SQL);
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        return rs;
    }
    
}
