/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dados;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Emylle Matos
 */
public class Compras {

    /**
     * @return the data
     */
    public Date getData() {
        return data;
    }

    /**
     * @param data the data to set
     */
    public void setData(Date data) {
        this.data = data;
    }

    /**
     * @return the ValorTotal
     */
    public float getValorTotal() {
        return ValorTotal;
    }

    /**
     * @param ValorTotal the ValorTotal to set
     */
    public void setValorTotal(float ValorTotal) {
        this.ValorTotal = ValorTotal;
    }

    /**
     * @return the CodigoCompra
     */
    public int getCodigoCompra() {
        return CodigoCompra;
    }

    /**
     * @param CodigoCompra the CodigoCompra to set
     */
    public void setCodigoCompra(int CodigoCompra) {
        this.CodigoCompra = CodigoCompra;
    }

    /**
     * @return the CNPJ
     */
    public int getCNPJ() {
        return CNPJ;
    }

    /**
     * @param CNPJ the CNPJ to set
     */
    public void setCNPJ(int CNPJ) {
        this.CNPJ = CNPJ;
    }

    /**
     * @return the CodigoTiposPaga
     */
    public int getCodigoTiposPaga() {
        return CodigoTiposPaga;
    }

    /**
     * @param CodigoTiposPaga the CodigoTiposPaga to set
     */
    public void setCodigoTiposPaga(int CodigoTiposPaga) {
        this.CodigoTiposPaga = CodigoTiposPaga;
    }
    
    private static Date data;
    private static float ValorTotal;
    private static int CodigoCompra;
    private static int CNPJ;
    private static int CodigoTiposPaga;
    
    public void InserirCompras(){
         PreparedStatement ps = null;         
        try { 
            ps = dados.Conexao.getConexao().prepareStatement("INSERT INTO Compras (CodigoTiposPaga, CNPJ, CodigoCompra, ValorTotal, data) VALUES (?,?,?,?,?)");
            
            ps.setInt(1, CodigoTiposPaga);
            ps.setInt(2, CNPJ);
            ps.setInt(3, CodigoCompra);
            ps.setFloat(4, ValorTotal);
            ps.setDate(5, data);
            
            ps.executeUpdate();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    
    public void EditarCompras(){
         PreparedStatement ps = null;         
        try { 
            ps = dados.Conexao.getConexao().prepareStatement("update Compras set CodigoTiposPaga = ?, CNPJ = ?, CodigoCompra = ?, ValorTotal = ?, data = ? where CodigoCompra = ?");
            
            ps.setInt(1, CodigoTiposPaga);
            ps.setInt(2, CNPJ);
            ps.setInt(3, CodigoCompra);
            ps.setFloat(4, ValorTotal);
            ps.setDate(5, data);
            ps.setInt(6, CodigoCompra);
            
            ps.executeUpdate();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    
    public void ExcluirCompras(){
         PreparedStatement pst = null;         
        try { 
            pst = dados.Conexao.getConexao().prepareStatement("DELETE FROM Compras WHERE CodigoCompra = ?");
            
            pst.setInt(1, CodigoCompra);
            
            pst.executeUpdate();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    
    public ResultSet SelecionarCompras (String SQL){
        ResultSet rs = null;
        try {
           rs = Conexao.getConexao().createStatement().executeQuery(SQL);
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        return rs;
    }
    
}
