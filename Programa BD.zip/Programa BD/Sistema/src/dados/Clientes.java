/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dados;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Emylle Matos
 */
public class Clientes {

    /**
     * @return the logradouro
     */
    public String getLogradouro() {
        return logradouro;
    }

    /**
     * @param logradouro the logradouro to set
     */
    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    /**
     * @return the uf
     */
    public String getUf() {
        return uf;
    }

    /**
     * @param uf the uf to set
     */
    public void setUf(String uf) {
        this.uf = uf;
    }

    /**
     * @return the Nome_cadasClient
     */
    public String getNome_cadasClient() {
        return Nome_cadasClient;
    }

    /**
     * @param Nome_cadasClient the Nome_cadasClient to set
     */
    public void setNome_cadasClient(String Nome_cadasClient) {
        this.Nome_cadasClient = Nome_cadasClient;
    }

    /**
     * @return the cep
     */
    public String getCep() {
        return cep;
    }

    /**
     * @param cep the cep to set
     */
    public void setCep(String cep) {
        this.cep = cep;
    }

    /**
     * @return the cpf
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * @param cpf the cpf to set
     */
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    /**
     * @return the Telefone_Cli
     */
    public String getTelefone_Cli() {
        return Telefone_Cli;
    }

    /**
     * @param Telefone_Cli the Telefone_Cli to set
     */
    public void setTelefone_Cli(String Telefone_Cli) {
        this.Telefone_Cli = Telefone_Cli;
    }

    /**
     * @return the complemento
     */
    public String getComplemento() {
        return complemento;
    }

    /**
     * @param complemento the complemento to set
     */
    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    /**
     * @return the cidade
     */
    public String getCidade() {
        return cidade;
    }

    /**
     * @param cidade the cidade to set
     */
    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    /**
     * @return the bairro
     */
    public String getBairro() {
        return bairro;
    }

    /**
     * @param bairro the bairro to set
     */
    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    /**
     * @return the Data_de_Nascimento
     */
    public Date getData_de_Nascimento() {
        return Data_de_Nascimento;
    }

    /**
     * @param Data_de_Nascimento the Data_de_Nascimento to set
     */
    public void setData_de_Nascimento(Date Data_de_Nascimento) {
        this.Data_de_Nascimento = Data_de_Nascimento;
    }

    /**
     * @return the numero
     */
    public int getNumero() {
        return numero;
    }

    /**
     * @param numero the numero to set
     */
    public void setNumero(int numero) {
        this.numero = numero;
    }

    /**
     * @return the codigoClient
     */
    public int getCodigoClient() {
        return codigoClient;
    }

    /**
     * @param codigoClient the codigoClient to set
     */
    public void setCodigoClient(int codigoClient) {
        this.codigoClient = codigoClient;
    }
    
    private static String logradouro;
    private static String uf;
    private static String Nome_cadasClient;
    private static String cep;
    private static String cpf;
    private static String Telefone_Cli;
    private static String complemento;
    private static String cidade;
    private static String bairro;
    private static Date Data_de_Nascimento;
    private static int numero;
    private static int codigoClient;
    
    public void InserirClientes(){
        //codigo não tem que ser gerado?
        PreparedStatement ps = null;
 
        try{
            
        ps = dados.Conexao.getConexao().prepareStatement("Insert into cliente (Logradouro, UF, Nome_cadasCLient, CEP, CPF, Telefone_Cli, Data_de_Nascimento, Complemento, Cidade, Numero, Bairro, CodigoClient) Values (?,?,?,?,?,?,?,?,?,?,?,?)");
            
        ps.setString(1, logradouro);
        ps.setString(2, uf);
        ps.setString(3, Nome_cadasClient);
        ps.setString(4, cep);
        ps.setString(5, cpf);
        ps.setString(6, Telefone_Cli);
        ps.setDate(7, Data_de_Nascimento);
        ps.setString(8, complemento);
        ps.setString(9, cidade);
        ps.setInt(10, numero);
        ps.setString(11, bairro);
        ps.setInt(12, codigoClient);
        
        ps.executeUpdate();
     
        } catch (Exception e){
         System.out.println(e.getMessage());
        }
        
    }
    
    public void EditarClientes(){
        PreparedStatement ps = null;   
         
        try { 
        ps = dados.Conexao.getConexao().prepareStatement("update cliente set Logradouro = ?, UF = ?, Nome_cadasCLient = ?, CEP = ?, CPF = ?, Telefone_Cli = ?, Data_de_Nascimento = ?, Complemento = ?, Cidade = ?, Numero = ?, Bairro = ?, CodigoClient = ? where CodigoClient = ?");
                 
        ps.setString(1, logradouro);
        ps.setString(2, uf);
        ps.setString(3, Nome_cadasClient);
        ps.setString(4, cep);
        ps.setString(5, cpf);
        ps.setString(6, Telefone_Cli);
        ps.setDate(7, Data_de_Nascimento);
        ps.setString(8, complemento);
        ps.setString(9, cidade);
        ps.setInt(10, numero);
        ps.setString(11, bairro);
        ps.setInt(12, codigoClient);
        ps.setInt(13, codigoClient);
        
        ps.executeUpdate();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    
    public void ExcluirClientes(){
         PreparedStatement ps = null;         
        try { 
            ps = dados.Conexao.getConexao().prepareStatement("DELETE FROM cliente WHERE codigoClient = ?");
            
            ps.setInt(1, codigoClient);
            
            ps.executeUpdate();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    
    public ResultSet SelecionarClientes (String SQL){
        ResultSet rs = null;
        try {
           rs = Conexao.getConexao().createStatement().executeQuery(SQL);
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        return rs;
    }
        
}
