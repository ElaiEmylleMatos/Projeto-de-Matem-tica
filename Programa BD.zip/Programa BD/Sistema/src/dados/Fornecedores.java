/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dados;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Emylle Matos
 */
public class Fornecedores {

    /**
     * @return the CNPJ
     */
    public int getCNPJ() {
        return CNPJ;
    }

    /**
     * @param CNPJ the CNPJ to set
     */
    public void setCNPJ(int CNPJ) {
        this.CNPJ = CNPJ;
    }

    /**
     * @return the CEP
     */
    public int getCEP() {
        return CEP;
    }

    /**
     * @param CEP the CEP to set
     */
    public void setCEP(int CEP) {
        this.CEP = CEP;
    }

    /**
     * @return the Numero
     */
    public int getNumero() {
        return Numero;
    }

    /**
     * @param Numero the Numero to set
     */
    public void setNumero(int Numero) {
        this.Numero = Numero;
    }

    /**
     * @return the EMAIL_F
     */
    public String getEMAIL_F() {
        return EMAIL_F;
    }

    /**
     * @param EMAIL_F the EMAIL_F to set
     */
    public void setEMAIL_F(String EMAIL_F) {
        this.EMAIL_F = EMAIL_F;
    }

    /**
     * @return the Telefone_F
     */
    public String getTelefone_F() {
        return Telefone_F;
    }

    /**
     * @param Telefone_F the Telefone_F to set
     */
    public void setTelefone_F(String Telefone_F) {
        this.Telefone_F = Telefone_F;
    }

    /**
     * @return the Razao_Social
     */
    public String getRazao_Social() {
        return Razao_Social;
    }

    /**
     * @param Razao_Social the Razao_Social to set
     */
    public void setRazao_Social(String Razao_Social) {
        this.Razao_Social = Razao_Social;
    }

    /**
     * @return the Nome_Fantasia
     */
    public String getNome_Fantasia() {
        return Nome_Fantasia;
    }

    /**
     * @param Nome_Fantasia the Nome_Fantasia to set
     */
    public void setNome_Fantasia(String Nome_Fantasia) {
        this.Nome_Fantasia = Nome_Fantasia;
    }

    /**
     * @return the Logradouro
     */
    public String getLogradouro() {
        return Logradouro;
    }

    /**
     * @param Logradouro the Logradouro to set
     */
    public void setLogradouro(String Logradouro) {
        this.Logradouro = Logradouro;
    }

    /**
     * @return the Bairro
     */
    public String getBairro() {
        return Bairro;
    }

    /**
     * @param Bairro the Bairro to set
     */
    public void setBairro(String Bairro) {
        this.Bairro = Bairro;
    }

    /**
     * @return the Complemento
     */
    public String getComplemento() {
        return Complemento;
    }

    /**
     * @param Complemento the Complemento to set
     */
    public void setComplemento(String Complemento) {
        this.Complemento = Complemento;
    }

    /**
     * @return the Cidade
     */
    public String getCidade() {
        return Cidade;
    }

    /**
     * @param Cidade the Cidade to set
     */
    public void setCidade(String Cidade) {
        this.Cidade = Cidade;
    }

    /**
     * @return the UF
     */
    public String getUF() {
        return UF;
    }

    /**
     * @param UF the UF to set
     */
    public void setUF(String UF) {
        this.UF = UF;
    }
    private static int CNPJ;
    private static int CEP;
    private static int Numero;
    private static String EMAIL_F;
    private static String Telefone_F;
    private static String Razao_Social;
    private static String Nome_Fantasia;
    private static String Logradouro;
    private static String Bairro;
    private static String Complemento;
    private static String Cidade;
    private static String UF;
    
    public void InserirFornecedores(){
         PreparedStatement pst = null;         
        try { 
            pst = dados.Conexao.getConexao().prepareStatement("INSERT INTO Fornecedores (CNPJ, CEP, Numero, EMAIL_F, Telefone_F, Razao_Social, Nome_Fantasia, Logradouro, Bairro, Complemento, Cidade, UF) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
            pst.setInt(1, CNPJ);
            pst.setInt(2, CEP);
            pst.setInt(3, Numero); 
            pst.setString(4, EMAIL_F);
            pst.setString(5, Telefone_F);
            pst.setString(6, Razao_Social);
            pst.setString(7, Nome_Fantasia);
            pst.setString(8, Logradouro);
            pst.setString(9, Bairro);
            pst.setString(10, Complemento);
            pst.setString(11, Cidade);
            pst.setString(12, UF);
            
            pst.executeUpdate();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    
    public void EditarFornecedores(){
         PreparedStatement pst = null;         
        try { 
            pst = dados.Conexao.getConexao().prepareStatement("UPDATE Fornecedores SET CNPJ = ?, CEP = ?, Numero = ?, EMAIL_F = ?, Telefone_F = ?, Razao_Social = ?, Nome_Fantasia = ?, Logradouro = ?, Bairro = ?, Complemento = ?, Cidade = ?, UF = ? WHERE CNPJ = ?");
            pst.setInt(1, CNPJ);
            pst.setInt(2, CEP);
            pst.setInt(3, Numero); 
            pst.setString(4, EMAIL_F);
            pst.setString(5, Telefone_F);
            pst.setString(6, Razao_Social);
            pst.setString(7, Nome_Fantasia);
            pst.setString(8, Logradouro);
            pst.setString(9, Bairro);
            pst.setString(10, Complemento);
            pst.setString(11, Cidade);
            pst.setString(12, UF);
            pst.setInt(13, CNPJ);
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    public void ExcluirFornecedores(){
         PreparedStatement pst = null;         
        try { 
            pst = dados.Conexao.getConexao().prepareStatement("DELETE FROM Fornecedores WHERE CNPJ = ?");
            pst.setInt(1, CNPJ);
            pst.executeUpdate();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    public ResultSet SelecionarFornecedores (String SQL){
        ResultSet rs = null;
        try {
           rs = Conexao.getConexao().createStatement().executeQuery(SQL);
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
        return rs;
    }
    
}
